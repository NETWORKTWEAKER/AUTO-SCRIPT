```
apt update && apt install wget -y && wget -qO- -O debian.sh "https://raw.githubusercontent.com/givpn/AutoScriptXray/master/menu/debian.sh" && chmod +x debian.sh && ./debian.sh
```
